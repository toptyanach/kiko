const Discord = require("discord.js");
const kiko = new Discord.Client({disableEveryone: true});
const prefix = "-";
const getImageColors = require('get-image-colors');
const forEachTimeout = require ('foreach-timeout');
const colors = ["FF0D00","FF2800","FF3D00","FF4F00","FF5F00","FF6C00","FF7800","FF8300","FF8C00","FF9500","FF9E00","FFA500","FFAD00","FFB400","FFBB00","FFC200","FFC900","FFCF00","FFD600","FFDD00","FFE400","FFEB00","FFF200","FFFA00","F7FE00","E5FB00","D5F800","C6F500","B7F200","A8F000","98ED00","87EA00","74E600","5DE100","41DB00","1DD300","00C618","00BB3F","00B358","00AC6B","00A67C","009E8E","028E9B","06799F","0969A2","0C5DA5","0E51A7","1047A9","133CAC","1531AE","1924B1","1F1AB2","2A17B1","3415B0","3C13AF","4512AE","4E10AE","560EAD","600CAC","6A0AAB","7608AA","8506A9","9702A7","AD009F","BC008D","C7007D","D0006E","D8005F","DF004F","E7003E","EF002A","F80012"];
const stop = [];

kiko.login("NDY1OTIzOTE0Nzk5Nzc1NzY0.DiX1iw.XHBi-7DVNKNXRx4Jv8ySW0pXY7o");

kiko.on('ready', () => {
    kiko.user.setPresence({ game: { name: `за ⭐ S H I N O B I ⭐`, type: 3 } }).catch();
});

kiko.on("message", (message) => {

    if(message.content == `${prefix}ping`) {
        let botembed = new Discord.RichEmbed() 
        .setColor("87CEFA")
        .setDescription("Pong!")

        return message.channel.send(botembed);
    }
});

kiko.on("message", (message) => {

    if(message.content == `${prefix}botinfo`){
        let botembed = new Discord.RichEmbed()
        .setTitle("Information:")
        .setDescription(`**Bot name:** KiKo __**BOT**__ \n **Version:** 1.0 (obt)\n **BotOwner:** KiKo.♡#0846\n **DSC:** Бот разработанный длsя сервера SHINOBI.\n`)
        .setColor("87CEFA");

        return message.channel.send(botembed);
    }
});

async function color () {
    forEachTimeout(colors, (color) => {
        kiko.guilds.forEach((guild) => {
                if (!stop.includes(guild.id)) {
                let role = guild.roles.find('name', '🌈Rainbow🌈');
                if (role && role.editable) 
                    role.setColor(color);
            }  
        })
    }, 500).then(color);
}
kiko.on('ready', () => {
    color();
});

kiko.on('message', (message) => {
    if (message.member.hasPermission('MANAGE_GUILD') || message.member.hasPermission('ADMINISTRATOR') || message.member.id === message.guild.owner.id) {
        if (message.content === `${prefix}stay`) {stop.push(message.guild.id); return message.channel.send('Готово');}
        if (message.content === `${prefix}go`) {stop.splice(stop.indexOf(message.guild.id),1); return message.channel.send('Готово');}
    }
});

kiko.on('message', (message) => {
    if (message.content.startsWith(`${prefix}avatar`)){
        let user = message.mentions.users.first();
        if(!user) user = message.author;
        getImageColors(user.avatarURL).then(color => {
            let c = color.map(col => col.hex());
        let embed = new Discord.RichEmbed()
        .setDescription(`Аватар ${user}`)
        .setColor(c[0])
        .setImage(user.avatarURL);
    message.channel.send({embed});
        });
    }
});
